package com.hifz.prayerrec

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        build()
    }

    private fun build() {
        val sv = ScrollView(this)
        sv.background = pageBg(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 14), dp(this, 40), dp(this, 14), dp(this, 30))
        sv.addView(col)

        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        top.addView(roundIconButton(this, "✕", 38, UI.MU, UI.TX, 16) { finish() }, LinearLayout.LayoutParams(dp(this, 36), dp(this, 36)).apply { marginEnd = dp(this@SettingsActivity, 10) })
        top.addView(txt(this, "إعدادات المواقيت والتسجيل", 19, UI.GOLD, true))
        col.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@SettingsActivity, 14) })

        val fm = SimpleDateFormat("HH:mm", Locale.US)
        for (id in Sched.ids) {
            val cd = addCard(this, col, Sched.ar(id), UI.color(id))
            val preview = txt(this, "", 13, UI.MU)
            cd.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@SettingsActivity, 10) })

            fun refresh() {
                val a = Sched.adhan(id, Calendar.getInstance())
                val s = Sched.startAt(this, id, Calendar.getInstance())
                preview.text = "الأذان اليوم ${arNum(fm.format(a))}  ←  يبدأ التسجيل ${arNum(fm.format(Date(s)))}"
            }
            refresh()

            cd.addView(stepper(this, "تعديل وقت الأذان (دقيقة)", Sched.adj(this, id), -15, 15, "د", signed = true) { v ->
                Sched.p(this).edit().putInt("a_$id", v).apply(); Sched.scheduleAll(this); refresh()
            }, sepLp())

            cd.addView(stepper(this, "بدء التسجيل بعد الأذان", Sched.delay(this, id), 0, 60, "د") { v ->
                Sched.p(this).edit().putInt("d_$id", v).apply(); Sched.scheduleAll(this); refresh()
            }, sepLp())

            cd.addView(stepper(this, "مدة التسجيل", Sched.dur(this, id), 1, 120, "د") { v ->
                Sched.p(this).edit().putInt("r_$id", v).apply(); Sched.scheduleAll(this); refresh()
            }, sepLp())

            cd.addView(outlineButton(this, "استعادة الإعدادات الافتراضية لهذه الصلاة", UI.MU) {
                val defD = mapOf("fajr" to 18, "maghrib" to 5, "isha" to 15)
                val defR = mapOf("fajr" to 15, "maghrib" to 10, "isha" to 15)
                Sched.p(this).edit().putInt("a_$id", 0).putInt("d_$id", defD[id]!!).putInt("r_$id", defR[id]!!).apply()
                Sched.scheduleAll(this)
                startActivity(intent); finish()
            }, sepLp())
        }

        setContentView(sv)
    }

    private fun sepLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(this, 14)
        return lp
    }
}
