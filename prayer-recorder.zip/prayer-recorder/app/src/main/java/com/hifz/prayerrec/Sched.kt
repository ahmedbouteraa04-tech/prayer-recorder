package com.hifz.prayerrec

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Sched {
    val ids = listOf("fajr", "maghrib", "isha")
    private val defD = mapOf("fajr" to 18, "maghrib" to 5, "isha" to 15)
    private val defR = mapOf("fajr" to 15, "maghrib" to 10, "isha" to 15)

    fun ar(id: String) = when (id) {
        "fajr" -> "الفجر"
        "maghrib" -> "المغرب"
        "isha" -> "العشاء"
        else -> "اختبار"
    }

    fun p(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun delay(c: Context, id: String) = p(c).getInt("d_$id", defD[id]!!)
    fun dur(c: Context, id: String) = p(c).getInt("r_$id", defR[id]!!)
    fun adj(c: Context, id: String) = p(c).getInt("a_$id", 0)
    fun enabled(c: Context) = p(c).getBoolean("on", true)

    // خنشلة: خط العرض 35.4358 وخط الطول 7.1433 — زاويتا الفجر والعشاء 18 و17 (وزارة الشؤون الدينية الجزائرية)
    fun adhan(id: String, day: Calendar): Date {
        val prm = CalculationMethod.OTHER.parameters
        prm.fajrAngle = 18.0
        prm.ishaAngle = 17.0
        val d = DateComponents(day.get(Calendar.YEAR), day.get(Calendar.MONTH) + 1, day.get(Calendar.DAY_OF_MONTH))
        val t = PrayerTimes(Coordinates(35.4358, 7.1433), d, prm)
        return when (id) {
            "fajr" -> t.fajr
            "maghrib" -> t.maghrib
            else -> t.isha
        }
    }

    fun startAt(c: Context, id: String, day: Calendar): Long =
        adhan(id, day).time + (adj(c, id) + delay(c, id)) * 60000L

    fun next(c: Context, id: String): Long {
        val now = System.currentTimeMillis()
        for (k in 0..2) {
            val d = Calendar.getInstance()
            d.add(Calendar.DAY_OF_MONTH, k)
            val t = startAt(c, id, d)
            if (t > now + 2000) return t
        }
        return now + 86400000L
    }

    private fun pend(c: Context, id: String, dur: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", id).putExtra("dur", dur)
        val code = if (id == "test") 10 else ids.indexOf(id) + 1
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun set(c: Context, id: String, at: Long, dur: Int) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pend(c, id, dur)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        for (id in ids) {
            am.cancel(pend(c, id, 0))
            if (enabled(c)) set(c, id, next(c, id), dur(c, id))
        }
        try { PrayerWidgetProvider.updateAll(c) } catch (e: Exception) {}
    }

    fun log(c: Context, s: String) {
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date())
        val old = p(c).getString("log", "") ?: ""
        val l = (listOf("$f — $s") + old.split("\n").filter { it.isNotBlank() }).take(25)
        p(c).edit().putString("log", l.joinToString("\n")).apply()
    }
}
