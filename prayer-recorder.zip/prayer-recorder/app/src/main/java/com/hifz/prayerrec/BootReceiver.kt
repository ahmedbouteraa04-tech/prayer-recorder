package com.hifz.prayerrec

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.scheduleAll(c)
        val mgr = android.appwidget.AppWidgetManager.getInstance(c)
        val ids = mgr.getAppWidgetIds(android.content.ComponentName(c, PrayerWidgetProvider::class.java))
        if (ids.isNotEmpty()) {
            PrayerWidgetProvider.scheduleTicks(c)
            PrayerWidgetProvider.updateAll(c)
        }
    }
}
