package com.hifz.prayerrec

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object UI {
    const val BG1 = 0xFF0E4244.toInt()
    const val BG2 = 0xFF061A20.toInt()
    const val CARD = 0x14FFFFFF
    const val CARD2 = 0x0DFFFFFF
    const val BORDER = 0x1FFFFFFF
    const val GOLD1 = 0xFFF6DC8E.toInt()
    const val GOLD2 = 0xFFC98F2E.toInt()
    const val GOLD = 0xFFE9C46A.toInt()
    const val GOLD_BORDER = 0x59E9C46A
    const val TX = 0xFFEEF6F2.toInt()
    const val MU = 0xFF8FB0A8.toInt()
    const val OK = 0xFF34C3A2.toInt()
    const val BAD = 0xFFFF9D80.toInt()
    const val FAJR = 0xFF8FC7E8.toInt()
    const val MAGHRIB = 0xFFE8A24A.toInt()
    const val ISHA = 0xFFB49CE8.toInt()

    fun color(id: String) = when (id) { "fajr" -> FAJR; "maghrib" -> MAGHRIB; else -> ISHA }
}

fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()
fun sp(c: Context, v: Int): Float = v.toFloat()

fun arNum(s: String): String {
    val ar = "٠١٢٣٤٥٦٧٨٩"
    val b = StringBuilder()
    for (ch in s) b.append(if (ch in '0'..'9') ar[ch - '0'] else ch)
    return b.toString()
}

fun rr(c: Context, radiusDp: Int, fill: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.cornerRadius = dp(c, radiusDp).toFloat()
    d.setColor(fill)
    if (strokeColor != 0) d.setStroke(dp(c, strokeDp.coerceAtLeast(1)), strokeColor)
    return d
}

fun grad(c: Context, colors: IntArray, radiusDp: Int = 0, strokeColor: Int = 0, strokeDp: Int = 1): GradientDrawable {
    val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)
    d.cornerRadius = dp(c, radiusDp).toFloat()
    if (strokeColor != 0) d.setStroke(dp(c, strokeDp), strokeColor)
    return d
}

fun oval(c: Context, fill: Int, strokeColor: Int = 0, strokeDp: Int = 1): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.OVAL
    d.setColor(fill)
    if (strokeColor != 0) d.setStroke(dp(c, strokeDp), strokeColor)
    return d
}

fun flatButton(c: Context) {}

fun txt(c: Context, t: String, sz: Int, col: Int, bold: Boolean = false, center: Boolean = false): TextView {
    val v = TextView(c)
    v.text = t
    v.textSize = sz.toFloat()
    v.setTextColor(col)
    if (bold) v.setTypeface(null, Typeface.BOLD)
    if (center) v.gravity = Gravity.CENTER
    return v
}

fun card(c: Context, bg: Int = UI.CARD, borderC: Int = UI.BORDER, radius: Int = 20): LinearLayout {
    val l = LinearLayout(c)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    l.background = rr(c, radius, bg, borderC, 1)
    return l
}

fun addCard(c: Context, into: LinearLayout, title: String? = null, titleColor: Int = UI.GOLD, marginBottom: Int = 12): LinearLayout {
    val cd = card(c)
    if (title != null) {
        val row = LinearLayout(c); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val dot = View(c); dot.background = oval(c, titleColor)
        row.addView(dot, LinearLayout.LayoutParams(dp(c, 9), dp(c, 9)).apply { marginEnd = dp(c, 8) })
        row.addView(txt(c, title, 18, titleColor, true))
        cd.addView(row)
        val sp = View(c); cd.addView(sp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 8)))
    }
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.bottomMargin = dp(c, marginBottom)
    into.addView(cd, lp)
    return cd
}

fun pageBg(c: Context): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(UI.BG2, UI.BG1, UI.BG2))

fun roundIconButton(c: Context, label: String, sizeDp: Int = 42, borderColor: Int = UI.GOLD, textColor: Int = UI.GOLD, textSize: Int = 18, onClick: () -> Unit): Button {
    val b = Button(c)
    b.text = label
    b.isAllCaps = false
    b.setTextColor(textColor)
    b.textSize = textSize.toFloat()
    b.background = oval(c, 0x00000000, borderColor, 1)
    b.stateListAnimator = null
    b.setPadding(0, 0, 0, 0)
    b.includeFontPadding = false
    b.setOnClickListener { onClick() }
    return b
}

fun goldFillButton(c: Context, label: String, onClick: () -> Unit): Button {
    val b = Button(c)
    b.text = label
    b.isAllCaps = false
    b.setTextColor(UI.BG2)
    b.textSize = 15f
    b.setTypeface(null, Typeface.BOLD)
    b.background = grad(c, intArrayOf(UI.GOLD1, UI.GOLD2), 14)
    b.stateListAnimator = null
    return b
}

fun outlineButton(c: Context, label: String, color: Int = UI.GOLD, onClick: () -> Unit): Button {
    val b = Button(c)
    b.text = label
    b.isAllCaps = false
    b.setTextColor(color)
    b.textSize = 14f
    b.background = rr(c, 14, 0x00000000, color, 1)
    b.stateListAnimator = null
    b.setOnClickListener { onClick() }
    return b
}

/** Builds a −/value/+ stepper row and returns its container. [after] fires on every change with the new value. */
fun stepper(c: Context, label: String, initial: Int, min: Int, max: Int, suffix: String, signed: Boolean = false, after: (Int) -> Unit): LinearLayout {
    val col = LinearLayout(c); col.orientation = LinearLayout.VERTICAL
    col.addView(txt(c, label, 13, UI.MU))
    val row = LinearLayout(c); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, dp(c, 4), 0, 0)
    var v = initial
    val valueTv = txt(c, fmtStep(v, suffix, signed), 17, UI.TX, true, true)
    valueTv.minWidth = dp(c, 84)
    fun set(nv: Int) {
        v = nv.coerceIn(min, max)
        valueTv.text = fmtStep(v, suffix, signed)
        after(v)
    }
    val minus = roundIconButton(c, "−") { set(v - 1) }
    val plus = roundIconButton(c, "+") { set(v + 1) }
    val sz = dp(c, 38)
    row.addView(minus, LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(c, 10) })
    row.addView(valueTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    row.addView(plus, LinearLayout.LayoutParams(sz, sz).apply { marginStart = dp(c, 10) })
    col.addView(row)
    return col
}

private fun fmtStep(v: Int, suffix: String, signed: Boolean): String {
    val s = if (signed && v > 0) "+${arNum(v.toString())}" else arNum(v.toString())
    return "$s $suffix"
}
