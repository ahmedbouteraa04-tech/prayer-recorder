package com.hifz.prayerrec

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LogActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        build()
    }

    private fun icon(msg: String): Pair<String, Int> = when {
        msg.contains("فشل") || msg.contains("تعذّر") || msg.contains("خطأ") -> "✕" to UI.BAD
        msg.contains("اكتمل") || msg.contains("أُوقف") -> "✓" to UI.OK
        msg.contains("اختبار") -> "🔔" to UI.GOLD
        else -> "⏺" to UI.GOLD
    }

    private fun dayLabel(dmy: String): String {
        // dmy like "14/11"
        val now = Calendar.getInstance()
        val todayS = SimpleDateFormat("dd/MM", Locale.US).format(now.time)
        now.add(Calendar.DAY_OF_MONTH, -1)
        val yestS = SimpleDateFormat("dd/MM", Locale.US).format(now.time)
        return when (dmy) { todayS -> "اليوم"; yestS -> "أمس"; else -> arNum(dmy) }
    }

    private fun build() {
        val sv = ScrollView(this)
        sv.background = pageBg(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 14), dp(this, 40), dp(this, 14), dp(this, 30))
        sv.addView(col)

        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        top.addView(roundIconButton(this, "✕", 38, UI.MU, UI.TX, 16) { finish() }, LinearLayout.LayoutParams(dp(this, 36), dp(this, 36)).apply { marginEnd = dp(this@LogActivity, 10) })
        top.addView(txt(this, "سجل الصلوات", 19, UI.GOLD, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(outlineButton(this, "مسح", UI.BAD) {
            Sched.p(this).edit().remove("log").apply()
            startActivity(intent); finish()
        })
        col.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@LogActivity, 16) })

        val raw = Sched.p(this).getString("log", "") ?: ""
        val lines = raw.split("\n").filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            val empty = card(this)
            empty.addView(txt(this, "لا شيء بعد. سيظهر هنا كل ما يحدث عند كل صلاة.", 14, UI.MU))
            col.addView(empty)
        } else {
            var lastDay = ""
            for (line in lines) {
                val parts = line.split(" — ", limit = 2)
                val time = parts.getOrNull(0) ?: ""
                val msg = parts.getOrNull(1) ?: line
                val dmy = time.split(" ").getOrNull(0) ?: ""
                val clock = time.split(" ").getOrNull(1) ?: time
                if (dmy != lastDay) {
                    lastDay = dmy
                    col.addView(txt(this, dayLabel(dmy), 12, UI.MU, true).apply { setPadding(dp(this@LogActivity, 4), dp(this@LogActivity, 10), 0, dp(this@LogActivity, 6)) })
                }
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                val (ic, icCol) = icon(msg)
                val iconView = txt(this, ic, 15, icCol, true, true)
                row.addView(iconView, LinearLayout.LayoutParams(dp(this, 28), dp(this, 28)))
                val body = card(this, UI.CARD2)
                body.setPadding(dp(this, 12), dp(this, 10), dp(this, 12), dp(this, 10))
                body.addView(txt(this, msg, 14, UI.TX))
                body.addView(txt(this, arNum(clock), 11, UI.MU).apply { setPadding(0, dp(this@LogActivity, 2), 0, 0) })
                row.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(this@LogActivity, 4) })
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(this, 8)
                col.addView(row, lp)
            }
        }
        setContentView(sv)
    }
}
