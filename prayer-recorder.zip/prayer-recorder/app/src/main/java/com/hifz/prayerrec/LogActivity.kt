package com.hifz.prayerrec

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

class LogActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        build()
    }

    private fun build() {
        val sv = ScrollView(this)
        sv.background = pageBg(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 14), dp(this, 40), dp(this, 14), dp(this, 30))
        sv.addView(col)

        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        top.addView(roundIconButton(this, "✕", 38, UI.MU, UI.TX, 16) { finish() }, LinearLayout.LayoutParams(dp(this, 36), dp(this, 36)).apply { marginEnd = dp(this@LogActivity, 10) })
        top.addView(txt(this, "سجل الصلوات", 19, UI.GOLD, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(outlineButton(this, "مسح", UI.BAD) {
            Sched.p(this).edit().remove("log").apply()
            startActivity(intent); finish()
        })
        col.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@LogActivity, 16) })

        val raw = Sched.p(this).getString("log", "") ?: ""
        val lines = raw.split("\n").filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            val empty = card(this)
            empty.addView(txt(this, "لا شيء بعد. سيظهر هنا كل ما يحدث عند كل صلاة.", 14, UI.MU))
            col.addView(empty)
        } else {
            for (line in lines) {
                val parts = line.split(" — ", limit = 2)
                val time = parts.getOrNull(0) ?: ""
                val msg = parts.getOrNull(1) ?: line
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
                val dotCol = LinearLayout(this); dotCol.orientation = LinearLayout.VERTICAL; dotCol.gravity = Gravity.CENTER_HORIZONTAL
                val dot = View(this); dot.background = oval(this, UI.GOLD)
                dotCol.addView(dot, LinearLayout.LayoutParams(dp(this, 9), dp(this, 9)).apply { topMargin = dp(this@LogActivity, 6) })
                row.addView(dotCol, LinearLayout.LayoutParams(dp(this, 20), LinearLayout.LayoutParams.MATCH_PARENT))
                val body = card(this, UI.CARD2)
                body.addView(txt(this, arNum(time), 11, UI.MU))
                body.addView(txt(this, msg, 14, UI.TX).apply { setPadding(0, dp(this@LogActivity, 2), 0, 0) })
                row.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(this, 10)
                col.addView(row, lp)
            }
        }
        setContentView(sv)
    }
}
