package com.hifz.prayerrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordService : Service() {
    private var rec: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var name = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        if (i?.action == "stop") {
            stopRec("أُوقف يدوياً")
            return START_NOT_STICKY
        }
        if (rec != null) return START_NOT_STICKY
        val id = i?.getStringExtra("id") ?: "test"
        val dur = i?.getIntExtra("dur", 15) ?: 15
        name = Sched.ar(id)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "التسجيل", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RecordService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("جارٍ تسجيل صلاة $name")
            .setContentText("يتوقف تلقائياً بعد $dur دقيقة")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        try {
            begin(dur)
            Sched.log(this, "بدأ تسجيل صلاة $name ($dur د)")
            PrayerWidgetProvider.setRecordingActive(this, name)
        } catch (e: Exception) {
            Sched.log(this, "فشل التسجيل: ${e.message}")
            cleanup(true)
            stopForeground(true)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun begin(dur: Int) {
        val now = Date()
        val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(now)
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        fun ins(path: String): Uri? {
            val cv = ContentValues()
            cv.put(MediaStore.Audio.Media.DISPLAY_NAME, "${date}_$name.m4a")
            cv.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            cv.put(MediaStore.Audio.Media.RELATIVE_PATH, path)
            cv.put(MediaStore.Audio.Media.IS_PENDING, 1)
            return contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv)
        }
        uri = try {
            ins("Recordings/Salat/$ym")
        } catch (e: Exception) {
            ins("Music/Salat/$ym")
        }
        val u = uri ?: throw Exception("تعذّر إنشاء الملف")
        pfd = contentResolver.openFileDescriptor(u, "w")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioChannels(1)
        r.setAudioSamplingRate(44100)
        r.setAudioEncodingBitRate(96000)
        r.setMaxDuration(dur * 60000)
        r.setOutputFile(pfd!!.fileDescriptor)
        r.setOnInfoListener { _, w, _ ->
            if (w == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stopRec("اكتمل")
        }
        r.setOnErrorListener { _, _, _ -> stopRec("خطأ في المسجّل") }
        r.prepare()
        r.start()
        rec = r
        val pm = getSystemService(PowerManager::class.java)
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "prayerrec:rec")
        wl?.acquire((dur + 2) * 60000L)
        h.postDelayed({ stopRec("اكتمل") }, dur * 60000L + 5000)
    }

    private fun stopRec(why: String) {
        if (rec == null && uri == null) {
            stopSelf()
            return
        }
        cleanup(false)
        Sched.log(this, "صلاة $name: $why")
        PrayerWidgetProvider.setRecordingActive(this, null)
        stopForeground(true)
        stopSelf()
    }

    private fun cleanup(failed: Boolean) {
        h.removeCallbacksAndMessages(null)
        var ok = !failed
        try { rec?.stop() } catch (e: Exception) { ok = false }
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        try { pfd?.close() } catch (e: Exception) { }
        pfd = null
        uri?.let {
            try {
                if (ok) {
                    val cv = ContentValues()
                    cv.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    contentResolver.update(it, cv, null, null)
                } else {
                    contentResolver.delete(it, null, null)
                }
            } catch (e: Exception) { }
        }
        uri = null
        try { wl?.release() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        cleanup(false)
        super.onDestroy()
    }
}
