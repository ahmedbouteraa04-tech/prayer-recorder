package com.hifz.prayerrec

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class LaunchActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        getSystemService(NotificationManager::class.java).cancel(2)
        val s = Intent(this, RecordService::class.java)
        s.putExtra("id", intent.getStringExtra("id"))
        s.putExtra("dur", intent.getIntExtra("dur", 15))
        try {
            startForegroundService(s)
        } catch (e: Exception) {
            Sched.log(this, "تعذّر بدء الخدمة: ${e.message}")
        }
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 1500)
    }
}
