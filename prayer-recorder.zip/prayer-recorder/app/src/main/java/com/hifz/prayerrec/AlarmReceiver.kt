package com.hifz.prayerrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val dur = i.getIntExtra("dur", 15)
        Sched.log(c, "حان وقت تسجيل ${Sched.ar(id)}")
        if (id != "test") Sched.scheduleAll(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("start", "بدء التسجيل", NotificationManager.IMPORTANCE_HIGH))
        val go = Intent(c, LaunchActivity::class.java).putExtra("id", id).putExtra("dur", dur).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(c, 100, go, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, "start")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("تسجيل ${Sched.ar(id)}")
            .setContentText("اضغط هنا إن لم يبدأ التسجيل")
            .setCategory(Notification.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(2, n)
        try {
            c.startActivity(go)
        } catch (e: Exception) {
            Sched.log(c, "تعذّر فتح الشاشة: ${e.message}")
        }
    }
}
