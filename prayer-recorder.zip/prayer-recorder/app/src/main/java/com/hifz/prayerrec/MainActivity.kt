package com.hifz.prayerrec

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var ticking = false

    private val perms: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        if (!Sched.p(this).getBoolean("asked", false)) {
            Sched.p(this).edit().putBoolean("asked", true).apply()
            requestPermissions(perms, 1)
        }
    }

    override fun onResume() {
        super.onResume()
        Sched.scheduleAll(this)
        ticking = true
        build()
    }

    override fun onPause() {
        super.onPause()
        ticking = false
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        build()
    }

    private fun pkgUri() = Uri.parse("package:$packageName")

    private fun statusRow(p: LinearLayout, label: String, ok: Boolean, grant: () -> Unit) {
        val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(this, 4), 0, dp(this, 4))
        val dot = View(this); dot.background = oval(this, if (ok) UI.OK else UI.BAD)
        r.addView(dot, LinearLayout.LayoutParams(dp(this, 8), dp(this, 8)).apply { marginEnd = dp(this@MainActivity, 10) })
        r.addView(txt(this, label, 14, if (ok) UI.TX else UI.BAD), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!ok) r.addView(outlineButton(this, "منح", UI.GOLD) { grant() })
        p.addView(r)
    }

    private fun build() {
        val outer = FrameLayout(this)
        outer.background = pageBg(this)

        val sv = ScrollView(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 14), dp(this, 44), dp(this, 14), dp(this, 30))
        sv.addView(col)
        outer.addView(sv)

        // top bar: title + corner buttons (settings, then overflow below it)
        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.TOP
        val logo = ImageView(this); logo.setImageResource(R.drawable.ic_launcher)
        top.addView(logo, LinearLayout.LayoutParams(dp(this, 40), dp(this, 40)).apply { marginEnd = dp(this@MainActivity, 10) })
        val titleCol = LinearLayout(this); titleCol.orientation = LinearLayout.VERTICAL
        titleCol.addView(txt(this, "مسجّل الصلوات الجهرية", 21, UI.GOLD, true))
        titleCol.addView(txt(this, "خنشلة · الفجر، المغرب، العشاء", 12, UI.MU))
        top.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val corner = LinearLayout(this); corner.orientation = LinearLayout.VERTICAL; corner.gravity = Gravity.END
        val gear = roundIconButton(this, "⚙", 42, UI.GOLD, UI.GOLD, 18) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        val dots = roundIconButton(this, "⋮", 42, UI.MU, UI.TX, 20) { }
        corner.addView(gear, LinearLayout.LayoutParams(dp(this, 40), dp(this, 40)))
        corner.addView(dots, LinearLayout.LayoutParams(dp(this, 40), dp(this, 40)).apply { topMargin = dp(this@MainActivity, 8) })
        dots.setOnClickListener { anchor ->
            val pm = PopupMenu(this, anchor)
            pm.menu.add(0, 1, 0, "سجل الصلوات")
            pm.menu.add(0, 2, 1, "التسجيلات المحفوظة")
            pm.setOnMenuItemClickListener { it ->
                when (it.itemId) {
                    1 -> startActivity(Intent(this, LogActivity::class.java))
                    2 -> startActivity(Intent(this, RecordingsActivity::class.java))
                }
                true
            }
            pm.show()
        }
        top.addView(corner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@MainActivity, 14) })

        // hero countdown card
        val hero = LinearLayout(this); hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(this, 18), dp(this, 18), dp(this, 18), dp(this, 18))
        hero.background = grad(this, intArrayOf(0xFF0E4244.toInt(), 0xFF0A2230.toInt()), 26, (UI.GOLD_BORDER).toInt(), 1)
        hero.addView(txt(this, "التسجيل القادم", 13, UI.MU))
        val nextId = Sched.ids.minByOrNull { Sched.next(this, it) } ?: "fajr"
        val nextAt = Sched.next(this, nextId)
        hero.addView(txt(this, Sched.ar(nextId), 30, UI.GOLD, true).apply { setPadding(0, dp(this@MainActivity, 2), 0, dp(this@MainActivity, 6)) })
        val countdownTv = txt(this, "", 34, UI.TX, true, true)
        hero.addView(countdownTv)
        val whenFmt = SimpleDateFormat("EEEE HH:mm", Locale("ar"))
        hero.addView(txt(this, arNum(whenFmt.format(Date(nextAt))), 13, UI.MU).apply { setPadding(0, dp(this@MainActivity, 6), 0, 0) })
        col.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@MainActivity, 14) })

        fun tick() {
            if (!ticking) return
            val left = (Sched.next(this, nextId) - System.currentTimeMillis()).coerceAtLeast(0) / 1000
            val hh = left / 3600; val mm = (left % 3600) / 60; val ss = left % 60
            countdownTv.text = arNum(String.format("%02d:%02d:%02d", hh, mm, ss))
            h.postDelayed({ tick() }, 1000)
        }
        tick()

        // status card
        val st = addCard(this, col, "الحالة")
        val sw = Switch(this)
        sw.text = "التسجيل التلقائي مفعّل"; sw.setTextColor(UI.TX)
        sw.isChecked = Sched.enabled(this)
        sw.setOnCheckedChangeListener { _, on -> Sched.p(this).edit().putBoolean("on", on).apply(); Sched.scheduleAll(this) }
        st.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@MainActivity, 4) })
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ntOk = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        statusRow(st, "الميكروفون والإشعارات", micOk && ntOk) { requestPermissions(perms, 1) }
        statusRow(st, "العرض فوق التطبيقات الأخرى", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri()))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            statusRow(st, "المنبّهات الدقيقة", am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri()))
            }
        }
        val pwm = getSystemService(PowerManager::class.java)
        statusRow(st, "استثناء البطارية (غير مقيّد)", pwm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri()))
        }

        // today schedule card
        val tc = addCard(this, col, "مواقيت اليوم")
        val fm = SimpleDateFormat("HH:mm", Locale.US)
        for (id in Sched.ids) {
            val a = Sched.adhan(id, Calendar.getInstance())
            val s = Sched.startAt(this, id, Calendar.getInstance())
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(this, 10), dp(this, 10), dp(this, 10), dp(this, 10))
            row.background = rr(this, 14, UI.CARD2, 0)
            val dot = View(this); dot.background = oval(this, UI.color(id))
            row.addView(dot, LinearLayout.LayoutParams(dp(this, 9), dp(this, 9)).apply { marginEnd = dp(this@MainActivity, 10) })
            val txtCol = LinearLayout(this); txtCol.orientation = LinearLayout.VERTICAL
            txtCol.addView(txt(this, Sched.ar(id), 15, UI.TX, true))
            txtCol.addView(txt(this, "الأذان ${arNum(fm.format(a))}  ←  التسجيل ${arNum(fm.format(Date(s)))} (${arNum(Sched.dur(this, id).toString())} د)", 12, UI.MU))
            row.addView(txtCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener {
                startActivity(Intent(this, RecordingsActivity::class.java).putExtra("focus", id))
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(this, 6)
            tc.addView(row, lp)
        }

        // test card
        val tt = addCard(this, col, "اختبار", marginBottom = 0)
        tt.addView(txt(this, "يبدأ تسجيل تجريبي مدته دقيقة بعد دقيقتين. اقفل الشاشة وانتظر.", 13, UI.MU).apply { setPadding(0, 0, 0, dp(this@MainActivity, 10)) })
        tt.addView(goldFillButton(this, "اختبار بعد دقيقتين") {
            Sched.set(this, "test", System.currentTimeMillis() + 120000L, 1)
            Toast.makeText(this, "سيبدأ التسجيل التجريبي بعد دقيقتين", Toast.LENGTH_LONG).show()
        })

        setContentView(outer)
    }
}
