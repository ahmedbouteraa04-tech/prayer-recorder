package com.hifz.prayerrec

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val BG = 0xFF061A20.toInt()
    private val CARD = 0xFF0E2A2E.toInt()
    private val GOLD = 0xFFE9C46A.toInt()
    private val TX = 0xFFEEF6F2.toInt()
    private val MU = 0xFF8FB0A8.toInt()
    private val OKC = 0xFF34C3A2.toInt()
    private val BAD = 0xFFFF9D80.toInt()
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val W = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val perms: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    private fun tv(t: String, sz: Float = 15f, col: Int = TX, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sz
        v.setTextColor(col)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(3), 0, dp(3))
        return v
    }

    private fun btn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun card(title: String, col: LinearLayout): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(18).toFloat()
        c.background = bg
        c.addView(tv(title, 18f, GOLD, true))
        val lp = LinearLayout.LayoutParams(M, W)
        lp.bottomMargin = dp(12)
        col.addView(c, lp)
        return c
    }

    private fun row(p: LinearLayout, t: String, ok: Boolean, f: () -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(tv((if (ok) "✓ " else "✗ ") + t, 14f, if (ok) OKC else BAD), LinearLayout.LayoutParams(0, W, 1f))
        if (!ok) r.addView(btn("منح") { f() })
        p.addView(r)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        if (!Sched.p(this).getBoolean("asked", false)) {
            Sched.p(this).edit().putBoolean("asked", true).apply()
            requestPermissions(perms, 1)
        }
    }

    override fun onResume() {
        super.onResume()
        Sched.scheduleAll(this)
        build()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        build()
    }

    private fun pkgUri() = Uri.parse("package:$packageName")

    private fun build() {
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(40), dp(14), dp(30))
        sv.addView(col)
        col.addView(tv("مسجّل الصلوات الجهرية", 26f, GOLD, true))
        col.addView(tv("خنشلة، الجزائر · الفجر والمغرب والعشاء", 13f, MU))

        val st = card("الحالة", col)
        val sw = Switch(this)
        sw.text = "التسجيل التلقائي مفعّل"
        sw.setTextColor(TX)
        sw.isChecked = Sched.enabled(this)
        sw.setOnCheckedChangeListener { _, on ->
            Sched.p(this).edit().putBoolean("on", on).apply()
            Sched.scheduleAll(this)
        }
        st.addView(sw)
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ntOk = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        row(st, "الميكروفون والإشعارات", micOk && ntOk) { requestPermissions(perms, 1) }
        row(st, "العرض فوق التطبيقات الأخرى", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri()))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            row(st, "المنبّهات الدقيقة", am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri()))
            }
        }
        val pm = getSystemService(PowerManager::class.java)
        row(st, "استثناء البطارية (غير مقيّد)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri()))
        }

        val tc = card("مواقيت اليوم والتسجيل", col)
        val fm = SimpleDateFormat("HH:mm", Locale.US)
        for (id in Sched.ids) {
            val a = Sched.adhan(id, Calendar.getInstance())
            val s = Sched.startAt(this, id, Calendar.getInstance())
            tc.addView(tv("${Sched.ar(id)}: الأذان ${fm.format(a)} ← تسجيل ${fm.format(Date(s))} (${Sched.dur(this, id)} د)", 14f))
        }
        val nx = Sched.ids.minOf { Sched.next(this, it) }
        tc.addView(tv("أقرب تسجيل قادم: " + SimpleDateFormat("EEEE HH:mm", Locale("ar")).format(Date(nx)), 13f, GOLD))

        val sc = card("الإعدادات (بالدقائق)", col)
        val fields = HashMap<String, EditText>()
        for (id in Sched.ids) {
            sc.addView(tv(Sched.ar(id), 15f, TX, true))
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((k, lbl, v) in listOf(
                Triple("d", "بعد الأذان", Sched.delay(this, id)),
                Triple("r", "المدة", Sched.dur(this, id)),
                Triple("a", "تعديل الأذان", Sched.adj(this, id))
            )) {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding(dp(4), 0, dp(4), 0)
                box.addView(tv(lbl, 11f, MU))
                val e = EditText(this)
                e.setText(v.toString())
                e.setTextColor(TX)
                e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
                fields["${k}_$id"] = e
                box.addView(e)
                r.addView(box, LinearLayout.LayoutParams(0, W, 1f))
            }
            sc.addView(r)
        }
        sc.addView(btn("حفظ الإعدادات") {
            val ed = Sched.p(this).edit()
            for ((key, e) in fields) {
                var n = e.text.toString().toIntOrNull() ?: continue
                if (key.startsWith("r_")) n = n.coerceIn(1, 120)
                ed.putInt(key, n)
            }
            ed.apply()
            Sched.scheduleAll(this)
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
            build()
        })

        val tt = card("اختبار", col)
        tt.addView(tv("يبدأ تسجيل تجريبي مدته دقيقة بعد دقيقتين. اقفل الشاشة وانتظر.", 13f, MU))
        tt.addView(btn("اختبار بعد دقيقتين") {
            Sched.set(this, "test", System.currentTimeMillis() + 120000L, 1)
            Toast.makeText(this, "سيبدأ التسجيل التجريبي بعد دقيقتين", Toast.LENGTH_LONG).show()
        })

        val lg = card("السجل", col)
        val log = Sched.p(this).getString("log", "") ?: ""
        lg.addView(tv(if (log.isBlank()) "لا شيء بعد" else log, 12f, MU))
        setContentView(sv)
    }
}
