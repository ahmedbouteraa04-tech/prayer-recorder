package com.hifz.prayerrec

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews

class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    override fun onEnabled(context: Context) {
        scheduleTicks(context)
        updateAll(context)
    }

    override fun onDisabled(context: Context) {
        cancelTicks(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == TICK) updateAll(context)
    }

    companion object {
        const val TICK = "com.hifz.prayerrec.WIDGET_TICK"

        fun updateAll(c: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(c)
                val ids = mgr.getAppWidgetIds(ComponentName(c, PrayerWidgetProvider::class.java))
                if (ids.isEmpty()) return
                val recording = Sched.p(c).getString("rec_active", null)
                val rv = RemoteViews(c.packageName, R.layout.widget_prayer)
                if (recording != null) {
                    rv.setTextViewText(R.id.w_status, "⏺ يسجّل الآن")
                    rv.setTextViewText(R.id.w_sub, "صلاة $recording")
                } else {
                    val nextId = Sched.ids.minByOrNull { Sched.next(c, it) } ?: "fajr"
                    val left = (Sched.next(c, nextId) - System.currentTimeMillis()).coerceAtLeast(0) / 60000
                    val hh = left / 60; val mm = left % 60
                    rv.setTextViewText(R.id.w_status, "التالي: ${Sched.ar(nextId)}")
                    val t = if (hh > 0) "خلال ${arNum(hh.toString())}س ${arNum(mm.toString())}د" else "خلال ${arNum(mm.toString())}د"
                    rv.setTextViewText(R.id.w_sub, t)
                }
                val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                rv.setOnClickPendingIntent(R.id.widget_root, open)
                for (id in ids) mgr.updateAppWidget(id, rv)
            } catch (e: Exception) {}
        }

        fun setRecordingActive(c: Context, name: String?) {
            Sched.p(c).edit().putString("rec_active", name).apply()
            updateAll(c)
        }

        private fun pend(c: Context): PendingIntent {
            val i = Intent(c, PrayerWidgetProvider::class.java).setAction(TICK)
            return PendingIntent.getBroadcast(c, 900, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun scheduleTicks(c: Context) {
            try {
                val am = c.getSystemService(AlarmManager::class.java)
                am.setRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 60000, 60000, pend(c))
            } catch (e: Exception) {}
        }

        fun cancelTicks(c: Context) {
            try {
                val am = c.getSystemService(AlarmManager::class.java)
                am.cancel(pend(c))
            } catch (e: Exception) {}
        }
    }
}
