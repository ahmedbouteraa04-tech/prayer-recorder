package com.hifz.prayerrec

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.RemoteViews

class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        updateAll(context)
    }

    override fun onEnabled(context: Context) {
        scheduleTicks(context)
        updateAll(context)
    }

    override fun onDisabled(context: Context) {
        cancelTicks(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == TICK) updateAll(context)
    }

    companion object {
        const val TICK = "com.hifz.prayerrec.WIDGET_TICK"
        private const val RED = 0xFFFF6B6B.toInt()
        private const val GOLD = 0xFFE9C46A.toInt()

        private fun clock(totalMin: Int): String {
            val hh = totalMin / 60
            val mm = totalMin % 60
            return arNum(String.format("%d:%02d", hh, mm))
        }

        private fun readable(totalMin: Int): String {
            val hh = totalMin / 60
            val mm = totalMin % 60
            return if (hh > 0) arNum("${hh}س ${mm}د") else arNum("${mm}د")
        }

        fun updateAll(c: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(c)
                val ids = mgr.getAppWidgetIds(ComponentName(c, PrayerWidgetProvider::class.java))
                if (ids.isEmpty()) return

                val recording: String? = Sched.p(c).getString("rec_active", null)
                val nextId = Sched.ids.minByOrNull { Sched.next(c, it) } ?: "fajr"
                val leftMin = ((Sched.next(c, nextId) - System.currentTimeMillis()).coerceAtLeast(0L) / 60000L).toInt()

                val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

                for (id in ids) {
                    val opts = mgr.getAppWidgetOptions(id)
                    val minW = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250)
                    val rv = if (minW < 150) small(c, recording, nextId, leftMin) else wide(c, recording, nextId, leftMin)
                    rv.setOnClickPendingIntent(R.id.widget_root, open)
                    mgr.updateAppWidget(id, rv)
                }
            } catch (e: Exception) {}
        }

        private fun small(c: Context, recording: String?, nextId: String, leftMin: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_small)
            if (recording != null) {
                rv.setTextViewText(R.id.w_big, "⏺")
                rv.setTextColor(R.id.w_big, RED)
                rv.setTextViewText(R.id.w_label, "يسجّل")
            } else {
                rv.setTextViewText(R.id.w_big, clock(leftMin))
                rv.setTextColor(R.id.w_big, GOLD)
                rv.setTextViewText(R.id.w_label, Sched.ar(nextId))
            }
            return rv
        }

        private fun wide(c: Context, recording: String?, nextId: String, leftMin: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_prayer)
            if (recording != null) {
                rv.setTextViewText(R.id.w_status, "يسجّل الآن")
                rv.setTextViewText(R.id.w_sub, "صلاة $recording")
                rv.setTextColor(R.id.w_dot, RED)
            } else {
                rv.setTextViewText(R.id.w_status, "التالي: ${Sched.ar(nextId)}")
                rv.setTextViewText(R.id.w_sub, "خلال " + readable(leftMin))
                rv.setTextColor(R.id.w_dot, GOLD)
            }
            return rv
        }

        fun setRecordingActive(c: Context, name: String?) {
            Sched.p(c).edit().putString("rec_active", name).apply()
            updateAll(c)
        }

        private fun pend(c: Context): PendingIntent {
            val i = Intent(c, PrayerWidgetProvider::class.java).setAction(TICK)
            return PendingIntent.getBroadcast(c, 900, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun scheduleTicks(c: Context) {
            try {
                val am = c.getSystemService(AlarmManager::class.java)
                am.setRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 60000L, 60000L, pend(c))
            } catch (e: Exception) {}
        }

        fun cancelTicks(c: Context) {
            try {
                val am = c.getSystemService(AlarmManager::class.java)
                am.cancel(pend(c))
            } catch (e: Exception) {}
        }
    }
}
