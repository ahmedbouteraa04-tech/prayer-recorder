package com.hifz.prayerrec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Rec(val id: Long, val uri: Uri, val name: String, val added: Long)

class RecordingsActivity : Activity() {
    private var player: MediaPlayer? = null
    private var playingId: Long = -1
    private var expandedId: Long = -1
    private var speed: Float = 1f
    private val perPage = 40
    private val shown = mutableMapOf("fajr" to perPage, "maghrib" to perPage, "isha" to perPage)
    private var grid = false

    private var curSeek: SeekBar? = null
    private var curTimeTv: TextView? = null
    private val tickH = Handler(Looper.getMainLooper())
    private val tickR = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && playingId != -1L) {
                try {
                    if (p.isPlaying) {
                        val d = p.duration.coerceAtLeast(0)
                        curSeek?.max = d
                        curSeek?.progress = p.currentPosition
                        curTimeTv?.text = "${fmtTime(p.currentPosition)} / ${fmtTime(d)}"
                    }
                } catch (e: Exception) {}
            }
            tickH.postDelayed(this, 300)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        grid = Sched.p(this).getBoolean("rec_grid", false)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_MEDIA_AUDIO), 2)
        }
        tickH.post(tickR)
        build()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        build()
    }

    override fun onDestroy() {
        tickH.removeCallbacks(tickR)
        stopPlayback()
        super.onDestroy()
    }

    private fun fmtTime(ms: Int): String {
        val s = ms / 1000
        return arNum(String.format("%d:%02d", s / 60, s % 60))
    }

    private fun stopPlayback() {
        try { player?.stop() } catch (e: Exception) {}
        try { player?.release() } catch (e: Exception) {}
        player = null
        playingId = -1
        curSeek = null
        curTimeTv = null
    }

    private fun query(): Map<String, MutableList<Rec>> {
        val out = mapOf("fajr" to mutableListOf<Rec>(), "maghrib" to mutableListOf<Rec>(), "isha" to mutableListOf<Rec>())
        val names = mapOf("fajr" to Sched.ar("fajr"), "maghrib" to Sched.ar("maghrib"), "isha" to Sched.ar("isha"))
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATE_ADDED)
        val sel = "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
        try {
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, arrayOf("%Salat%"), "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val dateI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idI); val name = c.getString(nameI) ?: continue; val added = c.getLong(dateI)
                    val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                    for ((key, ar) in names) if (name.contains(ar)) out[key]!!.add(Rec(id, uri, name, added))
                }
            }
        } catch (e: Exception) {}
        return out
    }

    private fun play(rec: Rec) {
        stopPlayback()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, rec.uri)
            mp.setOnCompletionListener { stopPlayback(); rebuild() }
            mp.prepare()
            try { mp.playbackParams = PlaybackParams().setSpeed(speed) } catch (e: Exception) {}
            mp.start()
            player = mp
            playingId = rec.id
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تشغيل الملف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlayPause(rec: Rec, onChange: () -> Unit) {
        val p = player
        if (playingId == rec.id && p != null) {
            try { if (p.isPlaying) p.pause() else p.start() } catch (e: Exception) {}
            onChange()
        } else {
            play(rec)
            rebuild()
        }
    }

    private fun confirmDelete(rec: Rec) {
        AlertDialog.Builder(this)
            .setTitle("حذف التسجيل؟")
            .setMessage(rec.name)
            .setPositiveButton("حذف") { _, _ ->
                if (playingId == rec.id) stopPlayback()
                if (expandedId == rec.id) expandedId = -1
                try { contentResolver.delete(rec.uri, null, null) } catch (e: Exception) {}
                rebuild()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** Self-contained seek bar + play/pause + speed + delete block for one recording. */
    private fun buildPlayerPanel(rec: Rec, onCollapse: (() -> Unit)?): LinearLayout {
        val panel = LinearLayout(this); panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(this, 4), dp(this, 6), dp(this, 4), dp(this, 2))
        val seek = SeekBar(this)
        panel.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val timeRow = LinearLayout(this); timeRow.orientation = LinearLayout.HORIZONTAL
        val timeTv = txt(this, "٠:٠٠ / ٠:٠٠", 11, UI.MU)
        timeRow.addView(timeTv)
        panel.addView(timeRow)

        if (playingId == rec.id) { curSeek = seek; curTimeTv = timeTv; try { seek.max = player?.duration?.coerceAtLeast(0) ?: 0; seek.progress = player?.currentPosition ?: 0 } catch (e: Exception) {} }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (playingId == rec.id) try { player?.seekTo(sb?.progress ?: 0) } catch (e: Exception) {}
            }
        })

        val ctrl = LinearLayout(this); ctrl.orientation = LinearLayout.HORIZONTAL; ctrl.gravity = Gravity.CENTER
        ctrl.setPadding(0, dp(this, 6), 0, 0)
        val playing = playingId == rec.id && player?.isPlaying == true
        val playBtn = roundIconButton(this, if (playing) "❚❚" else "▶", 34, UI.GOLD, UI.GOLD, 13) { }
        playBtn.setOnClickListener {
            togglePlayPause(rec) {
                val np = playingId == rec.id && player?.isPlaying == true
                playBtn.text = if (np) "❚❚" else "▶"
            }
        }
        val speedBtn = roundIconButton(this, speedLabel(speed), 34, UI.MU, UI.TX, 12) { }
        speedBtn.setOnClickListener {
            var idx = 0
            for (k in 0 until SPEEDS.size) {
                if (SPEEDS[k] == speed) idx = k
            }
            val nxt = (idx + 1) % SPEEDS.size
            speed = SPEEDS[nxt]
            speedBtn.text = speedLabel(speed)
            if (playingId == rec.id) try { player?.playbackParams = PlaybackParams().setSpeed(speed) } catch (e: Exception) {}
        }
        val delBtn = roundIconButton(this, "🗑", 34, UI.BAD, UI.BAD, 13) { confirmDelete(rec) }
        ctrl.addView(playBtn, LinearLayout.LayoutParams(dp(this, 34), dp(this, 34)).apply { marginEnd = dp(this@RecordingsActivity, 8) })
        ctrl.addView(speedBtn, LinearLayout.LayoutParams(dp(this, 46), dp(this, 34)).apply { marginEnd = dp(this@RecordingsActivity, 8) })
        ctrl.addView(delBtn, LinearLayout.LayoutParams(dp(this, 34), dp(this, 34)))
        if (onCollapse != null) {
            val close = roundIconButton(this, "✕", 30, UI.MU, UI.MU, 12) { onCollapse() }
            ctrl.addView(close, LinearLayout.LayoutParams(dp(this, 30), dp(this, 30)).apply { marginStart = dp(this@RecordingsActivity, 8) })
        }
        panel.addView(ctrl)
        return panel
    }

    private fun listColumn(id: String, recs: List<Rec>): LinearLayout {
        val colL = LinearLayout(this); colL.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER
        head.setPadding(0, 0, 0, dp(this, 10))
        val dot = View(this); dot.background = oval(this, UI.color(id))
        head.addView(dot, LinearLayout.LayoutParams(dp(this, 8), dp(this, 8)).apply { marginEnd = dp(this@RecordingsActivity, 6) })
        head.addView(txt(this, Sched.ar(id), 14, UI.color(id), true))
        colL.addView(head)
        colL.addView(txt(this, arNum("${recs.size}"), 11, UI.MU, center = true).apply { setPadding(0, 0, 0, dp(this@RecordingsActivity, 8)) })

        val fmt = SimpleDateFormat("dd/MM\nHH:mm", Locale.US)
        val limit = shown[id] ?: perPage
        if (recs.isEmpty()) colL.addView(txt(this, "لا تسجيلات", 11, UI.MU, center = true))
        for (rec in recs.take(limit)) {
            val item = LinearLayout(this); item.orientation = LinearLayout.VERTICAL
            item.setPadding(dp(this, 8), dp(this, 8), dp(this, 8), dp(this, 8))
            item.background = rr(this, 12, UI.CARD2, if (expandedId == rec.id) UI.GOLD else 0, 1)
            val row = LinearLayout(this); row.orientation = LinearLayout.VERTICAL; row.gravity = Gravity.CENTER
            row.addView(txt(this, arNum(fmt.format(Date(rec.added * 1000))), 11, UI.TX, center = true))
            item.addView(row)
            item.setOnClickListener {
                if (expandedId == rec.id) { expandedId = -1 } else { expandedId = rec.id; if (playingId != rec.id) play(rec) }
                rebuild()
            }
            if (expandedId == rec.id) item.addView(buildPlayerPanel(rec, null))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(this, 8)
            colL.addView(item, lp)
        }
        if (recs.size > limit) {
            colL.addView(outlineButton(this, "المزيد", UI.MU) { shown[id] = limit + perPage; rebuild() })
        }
        return colL
    }

    private fun openGridPlayer(rec: Rec) {
        if (playingId != rec.id) play(rec)
        val dlg = AlertDialog.Builder(this).setTitle(rec.name).setView(buildPlayerPanel(rec, null)).setOnDismissListener {
            curSeek = null; curTimeTv = null
        }.create()
        dlg.show()
    }

    private fun gridGallery(data: Map<String, MutableList<Rec>>): LinearLayout {
        val all = (data["fajr"] ?: emptyList()) + (data["maghrib"] ?: emptyList()) + (data["isha"] ?: emptyList())
        val sorted = all.sortedByDescending { it.added }
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        if (sorted.isEmpty()) { col.addView(txt(this, "لا تسجيلات بعد", 14, UI.MU, center = true)); return col }
        val fmt = SimpleDateFormat("dd/MM\nHH:mm", Locale.US)
        var i = 0
        while (i < sorted.size) {
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                if (i >= sorted.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f)); continue }
                val rec = sorted[i]; i++
                val id = if (rec.name.contains(Sched.ar("fajr"))) "fajr" else if (rec.name.contains(Sched.ar("maghrib"))) "maghrib" else "isha"
                val tile = LinearLayout(this); tile.orientation = LinearLayout.VERTICAL; tile.gravity = Gravity.CENTER
                tile.setPadding(dp(this, 6), dp(this, 10), dp(this, 6), dp(this, 10))
                tile.background = rr(this, 12, UI.CARD2, UI.color(id), 1)
                tile.addView(View(this).apply { setBackgroundColor(UI.color(id)) }, LinearLayout.LayoutParams(dp(this, 22), dp(this, 3)).apply { bottomMargin = dp(this@RecordingsActivity, 6) })
                tile.addView(txt(this, arNum(fmt.format(Date(rec.added * 1000))), 11, UI.TX, center = true))
                tile.setOnClickListener { openGridPlayer(rec) }
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.marginStart = dp(this, 4); lp.marginEnd = dp(this, 4); lp.bottomMargin = dp(this, 8)
                row.addView(tile, lp)
            }
            col.addView(row)
        }
        return col
    }

    private fun rebuild() = build()

    private fun build() {
        val focus = intent.getStringExtra("focus")
        val sv = ScrollView(this)
        sv.background = pageBg(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 10), dp(this, 40), dp(this, 10), dp(this, 30))
        sv.addView(col)

        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(this, 4), 0, dp(this, 4), 0)
        top.addView(roundIconButton(this, "✕", 38, UI.MU, UI.TX, 16) { finish() }, LinearLayout.LayoutParams(dp(this, 36), dp(this, 36)).apply { marginEnd = dp(this@RecordingsActivity, 10) })
        top.addView(txt(this, "التسجيلات المحفوظة", 18, UI.GOLD, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(outlineButton(this, if (grid) "☰ قائمة" else "▦ شبكة", UI.GOLD) {
            grid = !grid
            Sched.p(this).edit().putBoolean("rec_grid", grid).apply()
            rebuild()
        })
        col.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@RecordingsActivity, 14) })

        val data = query()
        if (grid) {
            col.addView(gridGallery(data))
        } else {
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
            for (id in Sched.ids) {
                val cd = card(this, UI.CARD, if (focus == id) UI.GOLD else UI.BORDER)
                cd.addView(listColumn(id, data[id] ?: emptyList()))
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.marginStart = dp(this, 4); lp.marginEnd = dp(this, 4)
                row.addView(cd, lp)
            }
            col.addView(row)
        }
        setContentView(sv)
    }
}
