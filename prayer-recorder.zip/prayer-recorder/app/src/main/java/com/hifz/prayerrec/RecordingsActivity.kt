package com.hifz.prayerrec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Rec(val id: Long, val uri: Uri, val name: String, val added: Long)

class RecordingsActivity : Activity() {
    private var player: MediaPlayer? = null
    private var playingId: Long = -1
    private val perPage = 40
    private val shown = mutableMapOf("fajr" to perPage, "maghrib" to perPage, "isha" to perPage)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = UI.BG2
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_MEDIA_AUDIO), 2)
        }
        build()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        build()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    private fun stopPlayback() {
        try { player?.stop() } catch (e: Exception) {}
        try { player?.release() } catch (e: Exception) {}
        player = null
        playingId = -1
    }

    private fun query(): Map<String, MutableList<Rec>> {
        val out = mapOf("fajr" to mutableListOf<Rec>(), "maghrib" to mutableListOf<Rec>(), "isha" to mutableListOf<Rec>())
        val names = mapOf("fajr" to Sched.ar("fajr"), "maghrib" to Sched.ar("maghrib"), "isha" to Sched.ar("isha"))
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATE_ADDED)
        val sel = "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
        try {
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, arrayOf("%Salat%"), "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val dateI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idI); val name = c.getString(nameI) ?: continue; val added = c.getLong(dateI)
                    val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                    for ((key, ar) in names) if (name.contains(ar)) out[key]!!.add(Rec(id, uri, name, added))
                }
            }
        } catch (e: Exception) {}
        return out
    }

    private fun column(id: String, recs: List<Rec>): LinearLayout {
        val colL = LinearLayout(this); colL.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this); head.orientation = LinearLayout.HORIZONTAL; head.gravity = Gravity.CENTER
        head.setPadding(0, 0, 0, dp(this, 10))
        val dot = View(this); dot.background = oval(this, UI.color(id))
        head.addView(dot, LinearLayout.LayoutParams(dp(this, 8), dp(this, 8)).apply { marginEnd = dp(this@RecordingsActivity, 6) })
        head.addView(txt(this, Sched.ar(id), 14, UI.color(id), true))
        colL.addView(head)
        colL.addView(txt(this, arNum("${recs.size}"), 11, UI.MU, center = true).apply { setPadding(0, 0, 0, dp(this@RecordingsActivity, 8)) })

        val fmt = SimpleDateFormat("dd/MM\nHH:mm", Locale.US)
        val limit = shown[id] ?: perPage
        if (recs.isEmpty()) {
            colL.addView(txt(this, "لا تسجيلات", 11, UI.MU, center = true))
        }
        for (rec in recs.take(limit)) {
            val item = LinearLayout(this); item.orientation = LinearLayout.VERTICAL
            item.setPadding(dp(this, 8), dp(this, 8), dp(this, 8), dp(this, 8))
            item.background = rr(this, 12, UI.CARD2, if (playingId == rec.id) UI.GOLD else 0, 1)
            item.gravity = Gravity.CENTER
            item.addView(txt(this, arNum(fmt.format(Date(rec.added * 1000))), 11, UI.TX, center = true))
            val btnRow = LinearLayout(this); btnRow.orientation = LinearLayout.HORIZONTAL; btnRow.gravity = Gravity.CENTER
            btnRow.setPadding(0, dp(this, 6), 0, 0)
            val playing = playingId == rec.id
            btnRow.addView(roundIconButton(this, if (playing) "❚❚" else "▶", 30, UI.GOLD, UI.GOLD, 12) {
                if (playing) { stopPlayback(); rebuild() } else { play(rec) }
            }, LinearLayout.LayoutParams(dp(this, 30), dp(this, 30)).apply { marginEnd = dp(this@RecordingsActivity, 6) })
            btnRow.addView(roundIconButton(this, "🗑", 30, UI.BAD, UI.BAD, 12) { confirmDelete(rec) }, LinearLayout.LayoutParams(dp(this, 30), dp(this, 30)))
            item.addView(btnRow)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(this, 8)
            colL.addView(item, lp)
        }
        if (recs.size > limit) {
            colL.addView(outlineButton(this, "المزيد", UI.MU) {
                shown[id] = limit + perPage
                rebuild()
            })
        }
        return colL
    }

    private fun play(rec: Rec) {
        stopPlayback()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, rec.uri)
            mp.setOnCompletionListener { stopPlayback(); rebuild() }
            mp.prepare()
            mp.start()
            player = mp
            playingId = rec.id
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تشغيل الملف", Toast.LENGTH_SHORT).show()
        }
        rebuild()
    }

    private fun confirmDelete(rec: Rec) {
        AlertDialog.Builder(this)
            .setTitle("حذف التسجيل؟")
            .setMessage(rec.name)
            .setPositiveButton("حذف") { _, _ ->
                if (playingId == rec.id) stopPlayback()
                try { contentResolver.delete(rec.uri, null, null) } catch (e: Exception) {}
                rebuild()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun rebuild() = build()

    private fun build() {
        val focus = intent.getStringExtra("focus")
        val sv = ScrollView(this)
        sv.background = pageBg(this)
        sv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(this, 10), dp(this, 40), dp(this, 10), dp(this, 30))
        sv.addView(col)

        val top = LinearLayout(this); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(this, 4), 0, dp(this, 4), 0)
        top.addView(roundIconButton(this, "✕", 38, UI.MU, UI.TX, 16) { finish() }, LinearLayout.LayoutParams(dp(this, 36), dp(this, 36)).apply { marginEnd = dp(this@RecordingsActivity, 10) })
        top.addView(txt(this, "التسجيلات المحفوظة", 18, UI.GOLD, true))
        col.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(this@RecordingsActivity, 14) })

        val data = query()
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        for (id in Sched.ids) {
            val cd = card(this, UI.CARD, if (focus == id) UI.GOLD else UI.BORDER)
            cd.addView(column(id, data[id] ?: emptyList()))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(this, 4); lp.marginEnd = dp(this, 4)
            row.addView(cd, lp)
        }
        col.addView(row)
        setContentView(sv)
    }
}
