plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.hifz.prayerrec"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.hifz.prayerrec"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.batoulapps.adhan:adhan:1.2.1")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
}
